package com.weatherapp.weather_forecast_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherForecastApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherForecastApiApplication.class, args);
    }

}
