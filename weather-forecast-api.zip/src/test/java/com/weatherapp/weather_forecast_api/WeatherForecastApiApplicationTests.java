package com.weatherapp.weather_forecast_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherForecastApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
